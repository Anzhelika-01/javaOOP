package shoppingSpree;

import java.util.Properties;

public class Test {
    public static void main(String[] args) {
        Properties properties = new Properties();
    }
}
