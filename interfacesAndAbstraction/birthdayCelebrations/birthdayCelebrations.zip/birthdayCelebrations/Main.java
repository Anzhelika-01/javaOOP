package birthdayCelebrations;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] line = scanner.nextLine().split("\\s+");
        List<String> dates = new LinkedList<>();

        while (!line[0].equals("End")) {
            switch (line[0]) {
                case "Citizen":
//                    String name = line[1];
//                    int age = Integer.parseInt(line[2]);
//                    String id = line[3];
                    String birthDate = line[4];
                    dates.add(birthDate);
                    break;
                case "Pet":
//                    name = line[1];
                    birthDate = line[2];
//                    Pet pet = new Pet(name, birthDate);
                    dates.add(birthDate);
                    break;
//                case "Robot":
//                    String model = line[1];
//                    id = line[2];
//                    Robot robot = new Robot(id, model);
//                    break;
            }
            line = scanner.nextLine().split("\\s+");
        }

        String year = scanner.nextLine();
        for (String date : dates){
            if (date.contains(year)){
                System.out.println(date);
            }
        }
    }
}