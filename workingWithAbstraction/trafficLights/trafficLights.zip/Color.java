package workingWithAbstraction.trafficLights;

public enum Color {
    RED(),
    GREEN(),
    YELLOW()
}